package br.com.fiap.biblioteca.dominio;

public interface Correios {

    public Endereco obterEndereco(String cep);
}
