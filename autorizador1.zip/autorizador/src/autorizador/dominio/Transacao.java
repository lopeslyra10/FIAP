package autorizador.dominio;

public class Transacao {

	private String numeroCartao;
	private int senhaCartao;
	private double valorRefeicao;
	
	public Transacao(String numeroCartao, int senhaCartao, double valorRefeicao) {
		this.numeroCartao = numeroCartao;
		this.senhaCartao = senhaCartao;
		this.valorRefeicao = valorRefeicao;
	}

	public String getNumeroCartao() {
		return numeroCartao;
	}

	public int getSenhaCartao() {
		return senhaCartao;
	}

	public double getValorRefeicao() {
		return valorRefeicao;
	}
}
