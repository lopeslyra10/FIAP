package autorizador;

import java.util.ArrayList;

import autorizador.dominio.Cartao;
import autorizador.dominio.Trabalhador;
import autorizador.dominio.Transacao;
import autorizador.servico.ServicoDeAutorizacao;

public class Main {
	
	public static void main(String[] args) {
		Cartao cartaoDoZe = new Cartao("546574376584372", 1234, 100);
		Cartao cartaoDoJota = new Cartao("347653478564369", 4567, 150);
		
		Trabalhador jose = new Trabalhador(cartaoDoZe);
		Trabalhador joao = new Trabalhador(cartaoDoJota);
		
		ArrayList<Trabalhador> trabalhadores = new ArrayList<>();
		trabalhadores.add(jose);
		trabalhadores.add(joao);
		
		ServicoDeAutorizacao servico = new ServicoDeAutorizacao(trabalhadores);
		
		Transacao umaTransacao = new Transacao("546574376584372", 1234, 100);
		
		boolean autorizou = servico.autorizar(umaTransacao);
		
		System.out.println("Transação autorizada? " + autorizou);
	}
}
