package autorizador.servico;

import java.util.ArrayList;

import autorizador.dominio.Cartao;
import autorizador.dominio.Trabalhador;
import autorizador.dominio.Transacao;

public class ServicoDeAutorizacao {

	private ArrayList<Trabalhador> trabalhadores;
	
	public ServicoDeAutorizacao(ArrayList<Trabalhador> trabalhadores) {
		this.trabalhadores = trabalhadores;
	}
	
//	public boolean autorizar(Transacao transacao) {
//		for(Trabalhador trabalhador : trabalhadores) {
//			String numeroCartao = transacao.getNumeroCartao();
//			if(trabalhador.possuiCartao(numeroCartao)) {
//				Cartao cartao = trabalhador.getCartao();
//				if(cartao.comSenha(transacao.getSenhaCartao())) {
//					double valorRefeicao = transacao.getValorRefeicao();
//					if(cartao.possuiSaldoPara(valorRefeicao)) {
//						return true;
//					}
//				}
//			}
//		}
//		return false;
//	}
	
	//abaixo uma outra opção de implementação do método autorizar()
	public boolean autorizar(Transacao transacao) {
		Trabalhador trabalhador = obterTrabalhadorPorNumeroDeCartao(transacao);
		if(trabalhador != null) {
			Cartao cartao = trabalhador.getCartao();
			return cartao.comSenha(transacao.getSenhaCartao())
					&& cartao.possuiSaldoPara(transacao.getValorRefeicao());
		}
		return false;
	}
	
	private Trabalhador obterTrabalhadorPorNumeroDeCartao(Transacao transacao) {
		for(Trabalhador trabalhador : trabalhadores) {
			String numeroCartao = transacao.getNumeroCartao();
			if(trabalhador.possuiCartao(numeroCartao)) {
				return trabalhador;
			}
		}
		return null;
	}
}
