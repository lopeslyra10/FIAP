import { Veiculo } from "./Veiculo";
export interface Carro extends Veiculo {
    portas: number;
}