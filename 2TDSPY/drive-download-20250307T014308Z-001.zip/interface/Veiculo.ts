export interface Veiculo {
    marca: string;
    modelo: string;
    ano: number;
    acelerar(): string;
}