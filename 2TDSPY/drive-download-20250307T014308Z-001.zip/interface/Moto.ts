import { Veiculo } from "./Veiculo";
export interface Moto extends Veiculo {
    cilindradas: number;
}