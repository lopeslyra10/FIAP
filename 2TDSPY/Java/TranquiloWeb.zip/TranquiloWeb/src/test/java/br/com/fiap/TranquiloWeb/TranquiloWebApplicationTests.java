package br.com.fiap.TranquiloWeb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TranquiloWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
